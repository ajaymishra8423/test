<?php
/* Simply redirect to Admin Panel - new upgrade home */
header('Location: ../scp/upgrade.php');
?>
