
            <div class="clear"></div>
        </div> <!-- content -->
    </div> <!-- wizard -->
    <div id="footer" class="centered">Copyright &copy; 2013 <a target="_blank" href="http://osticket.com">osTicket.com</a></div>
</body>
</html>
